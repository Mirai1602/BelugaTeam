# BelugaCalc

Calculadora de Álgebra Lineal desarrollada con Python y PyQt6.

## Ejecución

Desde la carpeta `BelugaCalc`:

```bash
python main.py
```

Requiere Python 3.10+ y PyQt6:

```bash
pip install PyQt6
```

## Módulos

- **Básica:** suma, resta y multiplicación de matrices con dimensiones configurables.
- **Avanzada:** Gauss, Gauss-Jordan y reducción de pivotes.
- **Conversiones:** conversiones entre decimal, binario, octal y hexadecimal.
- Las conversiones se realizan con Python estándar, sin NumPy, SciPy, `bin()`, `oct()` ni `hex()`.
- El procedimiento muestra divisiones sucesivas para conversiones desde decimal y la combinación lineal posicional para conversiones hacia decimal.

## Restricción académica

El módulo de conversiones utiliza listas, ciclos, condicionales y funciones de Python estándar, de acuerdo con el documento de la asignatura.
