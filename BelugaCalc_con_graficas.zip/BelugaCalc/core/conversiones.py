class Conversiones:
    """Conversiones entre bases numéricas usando únicamente Python estándar."""

    DIGITOS = "0123456789ABCDEF"

    @staticmethod
    def _validar_base(base):
        if base not in (2, 8, 10, 16):
            raise ValueError("La base debe ser 2, 8, 10 o 16.")

    @staticmethod
    def decimal_a_base(numero, base):
        """Convierte un entero decimal a otra base mediante divisiones sucesivas."""
        Conversiones._validar_base(base)
        try:
            numero = int(str(numero).strip())
        except ValueError:
            raise ValueError("Ingrese un número entero decimal válido.")

        if numero == 0:
            return "0", "0 = 0"

        signo = ""
        if numero < 0:
            signo = "-"
            numero = abs(numero)

        original = numero
        residuos = []
        pasos = []

        while numero > 0:
            cociente = numero // base
            residuo = numero % base
            digito = Conversiones.DIGITOS[residuo]
            residuos.append(digito)
            pasos.append(f"{numero} ÷ {base} = {cociente}, residuo {digito}")
            numero = cociente

        resultado = signo + "".join(reversed(residuos))
        procedimiento = (
            f"Conversión de {('-' if signo else '')}{original} a base {base}\n"
            + "\n".join(pasos)
            + "\nLeer los residuos de abajo hacia arriba: " + resultado
        )
        return resultado, procedimiento

    @staticmethod
    def base_a_decimal(numero, base):
        """Convierte desde una base a decimal mediante combinación lineal posicional."""
        Conversiones._validar_base(base)
        texto = str(numero).strip().upper()
        if not texto:
            raise ValueError("El número no puede estar vacío.")

        signo = 1
        if texto.startswith("-"):
            signo = -1
            texto = texto[1:]

        if not texto:
            raise ValueError("Ingrese un número válido.")

        valores = []
        for digito in texto:
            if digito not in Conversiones.DIGITOS:
                raise ValueError("El número contiene un dígito inválido.")
            valor = Conversiones.DIGITOS.index(digito)
            if valor >= base:
                raise ValueError(f"El dígito {digito} no pertenece a la base {base}.")
            valores.append(valor)

        decimal = 0
        terminos = []
        exponente_maximo = len(valores) - 1

        for posicion, valor in enumerate(valores):
            exponente = exponente_maximo - posicion
            aporte = valor * (base ** exponente)
            decimal += aporte
            terminos.append(f"{valor}×{base}^{exponente}={aporte}")

        decimal *= signo
        expresion = " + ".join(terminos)
        if signo == -1:
            expresion = f"-({expresion})"

        procedimiento = (
            f"Combinación lineal en base {base}:\n"
            f"{expresion}\n"
            f"Resultado decimal: {decimal}"
        )
        return decimal, procedimiento

    @staticmethod
    def decimal_a_binario(numero):
        return Conversiones.decimal_a_base(numero, 2)[0]

    @staticmethod
    def binario_a_decimal(binario):
        return Conversiones.base_a_decimal(binario, 2)[0]

    @staticmethod
    def decimal_a_octal(numero):
        return Conversiones.decimal_a_base(numero, 8)[0]

    @staticmethod
    def octal_a_decimal(octal):
        return Conversiones.base_a_decimal(octal, 8)[0]

    @staticmethod
    def decimal_a_hexadecimal(numero):
        return Conversiones.decimal_a_base(numero, 16)[0]

    @staticmethod
    def hexadecimal_a_decimal(hexadecimal):
        return Conversiones.base_a_decimal(hexadecimal, 16)[0]

    @staticmethod
    def convertir(numero, origen, destino):
        """Convierte entre bases soportadas y devuelve resultado y procedimiento."""
        Conversiones._validar_base(origen)
        Conversiones._validar_base(destino)

        if origen == destino:
            valor, procedimiento = Conversiones.base_a_decimal(numero, origen)
            return str(numero).strip().upper(), procedimiento + "\nLa base de origen y destino son iguales."

        decimal, procedimiento_entrada = Conversiones.base_a_decimal(numero, origen)
        resultado, procedimiento_salida = Conversiones.decimal_a_base(decimal, destino)
        procedimiento = (
            procedimiento_entrada
            + "\n\n"
            + procedimiento_salida
            + f"\n\nResultado final: {resultado}"
        )
        return resultado, procedimiento
