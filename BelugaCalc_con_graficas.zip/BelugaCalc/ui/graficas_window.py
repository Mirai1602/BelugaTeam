from PyQt6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel, QMessageBox
from PyQt6.QtGui import QPainter, QPen, QBrush, QColor, QFont
from PyQt6.QtCore import Qt, QPointF, QRectF


class GraficaWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.tipo = None
        self.matriz = None
        self.A = None
        self.B = None
        self.solucion = None
        self.clasificacion = ""
        self.titulo = ""
        self.setMinimumSize(700, 500)

    def mostrar_matriz(self, matriz, titulo="Resultado"):
        self.tipo = "matriz"
        self.matriz = matriz
        self.titulo = titulo
        self.update()

    def mostrar_sistema(self, A, B, solucion, clasificacion, titulo="Sistema"):
        self.tipo = "sistema"
        self.A = A
        self.B = B
        self.solucion = solucion
        self.clasificacion = clasificacion
        self.titulo = titulo
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QBrush(QColor(255, 255, 255)))

        if self.tipo == "matriz":
            self.dibujar_matriz(painter)
        elif self.tipo == "sistema":
            self.dibujar_sistema(painter)

        painter.end()

    def dibujar_matriz(self, painter):
        if not self.matriz or not isinstance(self.matriz, list):
            return

        filas = len(self.matriz)
        columnas = len(self.matriz[0]) if filas else 0

        if columnas == 0:
            return

        painter.setPen(QPen(QColor(30, 30, 30), 2))
        painter.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        painter.drawText(30, 35, self.titulo)

        painter.setFont(QFont("Arial", 11))
        painter.drawText(30, 60, "Representación visual de los valores de la matriz")

        izquierda = 70
        arriba = 100
        ancho_total = self.width() - 140
        alto_total = self.height() - 160

        ancho_celda = max(60, min(130, ancho_total // columnas))
        alto_celda = max(55, min(90, alto_total // filas))

        matriz_ancho = ancho_celda * columnas
        matriz_alto = alto_celda * filas
        izquierda = (self.width() - matriz_ancho) // 2
        arriba = max(100, (self.height() - matriz_alto) // 2)

        maximo = 0.0
        for fila in self.matriz:
            for valor in fila:
                try:
                    maximo = max(maximo, abs(float(valor)))
                except (ValueError, TypeError):
                    pass

        for i in range(filas):
            for j in range(columnas):
                valor = self.matriz[i][j]
                try:
                    numero = float(valor)
                except (ValueError, TypeError):
                    numero = 0.0

                if numero > 0 and maximo != 0:
                    intensidad = int(245 - 100 * abs(numero) / maximo)
                    fondo = QColor(220, intensidad, 245)
                elif numero < 0 and maximo != 0:
                    intensidad = int(245 - 100 * abs(numero) / maximo)
                    fondo = QColor(245, intensidad, intensidad)
                else:
                    fondo = QColor(245, 245, 245)

                x = izquierda + j * ancho_celda
                y = arriba + i * alto_celda

                painter.fillRect(
                    x,
                    y,
                    ancho_celda,
                    alto_celda,
                    QBrush(fondo)
                )
                painter.setPen(QPen(QColor(60, 60, 60), 1))
                painter.drawRect(x, y, ancho_celda, alto_celda)

                painter.setFont(QFont("Arial", 12))
                painter.setPen(QPen(QColor(20, 20, 20), 1))
                painter.drawText(
                    QRectF(x, y, ancho_celda, alto_celda),
                    Qt.AlignmentFlag.AlignCenter,
                    self.formatear(valor)
                )

    def dibujar_sistema(self, painter):
        if not self.A or not self.B:
            return

        variables = len(self.A[0])

        painter.setPen(QPen(QColor(30, 30, 30), 2))
        painter.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        painter.drawText(25, 30, self.titulo)

        painter.setFont(QFont("Arial", 10))
        painter.drawText(25, 52, self.clasificacion)

        if variables == 1:
            self.dibujar_una_variable(painter)
        elif variables == 2:
            self.dibujar_dos_variables(painter)
        elif variables == 3:
            self.dibujar_tres_variables(painter)
        else:
            self.dibujar_mas_de_tres_variables(painter)

    def dibujar_una_variable(self, painter):
        y = self.height() // 2
        inicio = 80
        fin = self.width() - 80

        painter.setPen(QPen(QColor(40, 40, 40), 2))
        painter.drawLine(inicio, y, fin, y)

        for valor in range(-10, 11):
            x = self.coordenada_x(valor, inicio, fin)
            painter.drawLine(x, y - 6, x, y + 6)
            painter.drawText(int(x - 10), y + 25, str(valor))

        solucion = self.valor_solucion(0)

        if solucion is not None:
            x = self.coordenada_x(solucion, inicio, fin)
            painter.setBrush(QBrush(QColor(0, 120, 215)))
            painter.setPen(QPen(QColor(0, 120, 215), 2))
            painter.drawEllipse(QPointF(x, y), 7, 7)
            painter.drawText(int(x - 35), y - 20, f"x = {self.formatear(solucion)}")

    def dibujar_dos_variables(self, painter):
        izquierda = 70
        derecha = self.width() - 50
        arriba = 80
        abajo = self.height() - 60

        x_min, x_max = -10, 10
        y_min, y_max = -10, 10

        def px(x):
            return izquierda + (x - x_min) * (derecha - izquierda) / (x_max - x_min)

        def py(y):
            return abajo - (y - y_min) * (abajo - arriba) / (y_max - y_min)

        painter.setPen(QPen(QColor(225, 225, 225), 1))

        for valor in range(-10, 11):
            painter.drawLine(px(valor), py(y_min), px(valor), py(y_max))
            painter.drawLine(px(x_min), py(valor), px(x_max), py(valor))

        painter.setPen(QPen(QColor(50, 50, 50), 2))
        painter.drawLine(px(x_min), py(0), px(x_max), py(0))
        painter.drawLine(px(0), py(y_min), px(0), py(y_max))

        for valor in range(-10, 11):
            painter.setFont(QFont("Arial", 8))
            painter.drawText(int(px(valor) - 8), int(py(0) + 18), str(valor))
            if valor != 0:
                painter.drawText(int(px(0) + 8), int(py(valor) + 4), str(valor))

        colores = [
            QColor(35, 95, 175),
            QColor(190, 60, 60),
            QColor(50, 130, 80),
            QColor(150, 90, 170),
            QColor(220, 130, 40)
        ]

        for i, (fila, independiente) in enumerate(zip(self.A, self.B)):
            a = float(fila[0])
            b = float(fila[1])
            c = float(independiente[0])

            painter.setPen(QPen(colores[i % len(colores)], 2))

            if a == 0 and b == 0:
                continue

            if b == 0:
                x = c / a
                painter.drawLine(px(x), py(y_min), px(x), py(y_max))
                continue

            anterior = None

            for paso in range(101):
                x = x_min + (x_max - x_min) * paso / 100
                y = (c - a * x) / b

                if abs(y) > 100:
                    anterior = None
                    continue

                punto = QPointF(px(x), py(y))

                if anterior is not None:
                    painter.drawLine(anterior, punto)

                anterior = punto

        x = self.valor_solucion(0)
        y = self.valor_solucion(1)

        if x is not None and y is not None:
            painter.setBrush(QBrush(QColor(0, 0, 0)))
            painter.setPen(QPen(QColor(0, 0, 0), 2))
            painter.drawEllipse(QPointF(px(x), py(y)), 6, 6)
            painter.drawText(
                int(px(x) + 10),
                int(py(y) - 10),
                f"({self.formatear(x)}, {self.formatear(y)})"
            )

    def dibujar_tres_variables(self, painter):
        centro_x = self.width() // 2
        centro_y = self.height() // 2 + 40
        escala = min(self.width(), self.height()) / 32

        def proyectar(x, y, z):
            px = centro_x + (x - y) * escala
            py = centro_y - (z + (x + y) * 0.5) * escala
            return QPointF(px, py)

        painter.setPen(QPen(QColor(70, 70, 70), 2))
        origen = proyectar(0, 0, 0)
        painter.drawLine(origen, proyectar(7, 0, 0))
        painter.drawLine(origen, proyectar(0, 7, 0))
        painter.drawLine(origen, proyectar(0, 0, 7))

        painter.setFont(QFont("Arial", 9))
        painter.drawText(proyectar(7, 0, 0), "X")
        painter.drawText(proyectar(0, 7, 0), "Y")
        painter.drawText(proyectar(0, 0, 7), "Z")

        colores = [
            QColor(35, 95, 175),
            QColor(190, 60, 60),
            QColor(50, 130, 80),
            QColor(150, 90, 170),
            QColor(220, 130, 40)
        ]

        for indice, (fila, independiente) in enumerate(zip(self.A, self.B)):
            a = float(fila[0])
            b = float(fila[1])
            c = float(fila[2])
            d = float(independiente[0])

            painter.setPen(QPen(colores[indice % len(colores)], 1))

            if c != 0:
                for x in range(-6, 7, 2):
                    puntos = []
                    for y in range(-6, 7, 2):
                        z = (d - a * x - b * y) / c
                        if abs(z) <= 10:
                            puntos.append(proyectar(x, y, z))
                    self.dibujar_segmentos(painter, puntos)

                for y in range(-6, 7, 2):
                    puntos = []
                    for x in range(-6, 7, 2):
                        z = (d - a * x - b * y) / c
                        if abs(z) <= 10:
                            puntos.append(proyectar(x, y, z))
                    self.dibujar_segmentos(painter, puntos)

            elif b != 0:
                for x in range(-6, 7, 2):
                    puntos = []
                    for z in range(-6, 7, 2):
                        y = (d - a * x - c * z) / b
                        if abs(y) <= 10:
                            puntos.append(proyectar(x, y, z))
                    self.dibujar_segmentos(painter, puntos)

                for z in range(-6, 7, 2):
                    puntos = []
                    for x in range(-6, 7, 2):
                        y = (d - a * x - c * z) / b
                        if abs(y) <= 10:
                            puntos.append(proyectar(x, y, z))
                    self.dibujar_segmentos(painter, puntos)

            elif a != 0:
                for y in range(-6, 7, 2):
                    puntos = []
                    for z in range(-6, 7, 2):
                        x = (d - b * y - c * z) / a
                        if abs(x) <= 10:
                            puntos.append(proyectar(x, y, z))
                    self.dibujar_segmentos(painter, puntos)

                for z in range(-6, 7, 2):
                    puntos = []
                    for y in range(-6, 7, 2):
                        x = (d - b * y - c * z) / a
                        if abs(x) <= 10:
                            puntos.append(proyectar(x, y, z))
                    self.dibujar_segmentos(painter, puntos)

        x = self.valor_solucion(0)
        y = self.valor_solucion(1)
        z = self.valor_solucion(2)

        if x is not None and y is not None and z is not None:
            punto = proyectar(x, y, z)
            painter.setBrush(QBrush(QColor(0, 0, 0)))
            painter.setPen(QPen(QColor(0, 0, 0), 2))
            painter.drawEllipse(punto, 6, 6)
            painter.drawText(
                int(punto.x() + 10),
                int(punto.y() - 10),
                f"({self.formatear(x)}, {self.formatear(y)}, {self.formatear(z)})"
            )

    def dibujar_segmentos(self, painter, puntos):
        for i in range(len(puntos) - 1):
            painter.drawLine(puntos[i], puntos[i + 1])

    def dibujar_mas_de_tres_variables(self, painter):
        texto = "La representación geométrica se realiza hasta 3 variables."
        painter.setFont(QFont("Arial", 12))
        painter.setPen(QPen(QColor(40, 40, 40), 1))
        painter.drawText(40, 120, texto)
        painter.drawText(40, 150, "Resultado del sistema:")

        if isinstance(self.solucion, list):
            for i, valor in enumerate(self.solucion):
                if isinstance(valor, list) and valor:
                    texto = f"x{i + 1} = {self.formatear(valor[0])}"
                else:
                    texto = f"x{i + 1} = {valor}"
                painter.drawText(60, 185 + i * 25, texto)
        else:
            painter.drawText(60, 185, str(self.solucion))

    def coordenada_x(self, valor, inicio, fin):
        return inicio + (valor + 10) * (fin - inicio) / 20

    def valor_solucion(self, indice):
        if not isinstance(self.solucion, list):
            return None

        if indice >= len(self.solucion):
            return None

        valor = self.solucion[indice]

        if isinstance(valor, list):
            if not valor:
                return None
            valor = valor[0]

        if isinstance(valor, (int, float)):
            return float(valor)

        try:
            return float(valor)
        except (ValueError, TypeError):
            return None

    def formatear(self, valor):
        try:
            numero = float(valor)
            if numero.is_integer():
                return str(int(numero))
            return f"{numero:.3f}"
        except (ValueError, TypeError):
            return str(valor)


class GraficasWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("BelugaCalc - Representación Gráfica")
        self.resize(900, 650)

        layout = QVBoxLayout()

        self.titulo = QLabel("Representación Gráfica")
        self.titulo.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        layout.addWidget(self.titulo)

        self.grafica = GraficaWidget()
        layout.addWidget(self.grafica)

        btn_cerrar = QPushButton("Cerrar")
        btn_cerrar.clicked.connect(self.close)
        layout.addWidget(btn_cerrar)

        self.setLayout(layout)

    def graficar_matriz(self, matriz, titulo="Resultado"):
        if not matriz or not isinstance(matriz, list):
            QMessageBox.warning(self, "Error", "No hay una matriz válida para representar.")
            return

        self.titulo.setText(titulo)
        self.grafica.mostrar_matriz(matriz, titulo)

    def graficar_sistema(self, A, B, solucion, clasificacion, titulo="Sistema"):
        if not A or not B:
            QMessageBox.warning(self, "Error", "No hay un sistema válido para representar.")
            return

        self.titulo.setText(titulo)
        self.grafica.mostrar_sistema(
            A,
            B,
            solucion,
            clasificacion,
            titulo
        )
